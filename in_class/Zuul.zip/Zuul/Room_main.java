public class Room_main {
    public static void main(String[] args) {
        Room Lobby = new Room("Lobby", "a waiting room");
        Lobby.getExit("west");
        Room Office = new Room("Office", "a large office");
        Room auditorium = new AUA_Roms("Large Auditorium", "1,346 seats\n" + //
        "Audio system, Large screen for presentations and movie-watching.\n", 9200);
        Room MainBuilding_1st_floor = new AUA_Roms("AUA Main Building", "It contains the Library , the Administration Office", 3200);
        MainBuilding_1st_floor.setExit("south", null);
        Room aquarium = new AUA_Roms("Aquarium Library", "Loud Studying Area" , 300);
        aquarium.setExit("east", MainBuilding_1st_floor);
        aquarium.getLongDescription();
        Room Library = new AUA_Roms("Papazian Library", "7 study rooms, books, computers", 1000);
        // Study rooms with east exits to the Library
        System.out.println(Lobby.getLongDescription());
        System.out.println(auditorium.getLongDescription());
        System.out.println(Library.getTitle());
        Lobby.setExit("west", Office);
        Lobby.getExit("west");
    }
}
