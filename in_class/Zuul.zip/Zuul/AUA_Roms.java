/**
     *This is  AUA building class 
     with respect to the Room class
     * 
     */
public class AUA_Roms extends Room{
private int num_students;


    /**
     * @param title
     * @param description
     */
    public AUA_Roms(String title, String description, int num_students) {
        super(title, description);
        this.num_students = num_students;
    }

    @Override
    public Room getExit(String direction) {
        return super.getExit(direction);
    }

    @Override
    public String[] getExitDirections() {
        return super.getExitDirections();
    }

    @Override
    public Item getItem(String itemName) {
        return super.getItem(itemName);
    }

    @Override
    public String getLongDescription() {
        return super.getLongDescription();
    }

    @Override
    public String getTitle() {
        return super.getTitle();
    }

    @Override
    public void setExit(String direction, Room neighbor) {
        super.setExit(direction, neighbor);
    }

    @Override
    public String listItems() {
        return super.listItems();
    }

    @Override
    public String getShortDescription() {
        return super.getShortDescription();
    }
        public int getNum_students() {
    return num_students;
}

public void setNum_students(int num_students) {
    this.num_students = num_students;
}

    
}
