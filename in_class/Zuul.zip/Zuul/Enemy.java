public interface Enemy {
    void damage(Player player);
}